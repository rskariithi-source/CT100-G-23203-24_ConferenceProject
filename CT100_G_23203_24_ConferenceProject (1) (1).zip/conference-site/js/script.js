// Get the form element
const regForm = document.getElementById('regForm');

// Task 5: Use of onsubmit event
regForm.onsubmit = function(event) {
    // Prevent the form from submitting by default until we check it
    event.preventDefault();

    if (validateForm()) {
        // If validation passes, submit the form
        regForm.submit();
    }
};

// Task 2: JavaScript Form Validation function
function validateForm() {
    let isValid = true;
    let errorText = "";

    // Get form values
    const fullName = document.getElementById('fullName').value.trim();
    const regNumber = document.getElementById('regNumber').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const confDays = parseInt(document.getElementById('confDays').value);

    const catConference = document.getElementById('catConference').checked;
    const catWorkshop = document.getElementById('catWorkshop').checked;

    // 1. Full name cannot be empty
    if (fullName === "") {
        errorText += "Full name cannot be empty.<br>";
        isValid = false;
    }

    // Registration number cannot be empty (process.php requires it too)
    if (regNumber === "") {
        errorText += "Admission/Registration number cannot be empty.<br>";
        isValid = false;
    }
    
    // 2. Email address must contain a valid email format
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        errorText += "Please enter a valid email address.<br>";
        isValid = false;
    }

    // 3. Phone number must contain exactly 10 digits
    if (phone.length !== 10 || isNaN(phone)) {
        errorText += "Phone number must contain exactly 10 digits.<br>";
        isValid = false;
    }

    // 4. Number of conference days must be between 1 and 3 days
    if (isNaN(confDays) || confDays < 1 || confDays > 3) {
        errorText += "Number of conference days must be between 1 and 3.<br>";
        isValid = false;
    }

    // 5. The participant must select a participation category
    if (!catConference && !catWorkshop) {
        errorText += "You must select a participation category.<br>";
        isValid = false;
    }

    // 6. Display appropriate error messages
    const errorDiv = document.getElementById('errorMessages');
    if (!isValid) {
        errorDiv.innerHTML = errorText; // Show errors
    } else {
        errorDiv.innerHTML = ""; // Clear errors if valid
    }

    // The form must not be submitted until the required information is valid
    return isValid;
}

// Task 3: Dynamic JavaScript Behavior
function toggleDynamicOptions() {
    const catConference = document.getElementById('catConference');
    const catWorkshop = document.getElementById('catWorkshop');
    const workshopSection = document.getElementById('workshopSection');
    const packageMessage = document.getElementById('packageMessage');
    const workshopSelect = document.getElementById('workshopSelect');

    if (catWorkshop.checked) {
        // Display additional workshop options when the participant selects Workshop Participant
        workshopSection.style.display = 'block';

        // Display a message indicating the selected conference package
        packageMessage.innerHTML = "<strong>Selected Package:</strong> Workshop Participant";
    } else if (catConference.checked) {
        // Hide workshop options when the participant selects Conference Only
        workshopSection.style.display = 'none';

        // Reset the workshop selection so it doesn't affect the calculation when hidden
        workshopSelect.value = "";

        // Display a message indicating the selected conference package
        packageMessage.innerHTML = "<strong>Selected Package:</strong> Conference Only";
    }
}

// Task 5: Use of onchange events
document.getElementById('catConference').onchange = toggleDynamicOptions;
document.getElementById('catWorkshop').onchange = toggleDynamicOptions;

// Task 4: Conference Fee Calculator
function calculateFee() {
    let totalFee = 0;

    // Base charges defined in the project
    const regFee = 1000;
    const attendancePerDay = 500;
    const workshopCharge = 750;
    const lunchPerDay = 300;

    // Get input values
    const daysInput = document.getElementById('confDays').value;
    const confDays = parseInt(daysInput) || 0; // default to 0 if empty

    const catWorkshop = document.getElementById('catWorkshop').checked;
    const mealOption = document.getElementById('mealOption').checked;
    const yearOfStudy = document.getElementById('yearOfStudy').value;

    // Only calculate if days are valid (1-3)
    if (confDays >= 1 && confDays <= 3) {
        // 1. Add Registration Fee
        totalFee += regFee;

        // 2. Add Attendance Fee
        totalFee += (confDays * attendancePerDay);

        // 3. Add Workshop Fee if selected
        if (catWorkshop) {
            totalFee += workshopCharge;
        }

        // 4. Add Meal Fee if selected
        if (mealOption) {
            totalFee += (confDays * lunchPerDay);
        }

        // INDIVIDUALIZATION REQUIREMENT (Digit 3): Give final-year students a 5% discount
        if (yearOfStudy === "Final Year") {
            // Apply 5% discount (multiply by 0.95)
            totalFee = totalFee * 0.95;
        }
    }

    // Display the calculated amount automatically on the page
    document.getElementById('totalAmount').innerText = totalFee.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Attach the calculateFee function to relevant events so it updates dynamically
document.getElementById('confDays').oninput = calculateFee;
document.getElementById('catConference').addEventListener('change', calculateFee);
document.getElementById('catWorkshop').addEventListener('change', calculateFee);
document.getElementById('mealOption').onchange = calculateFee;
document.getElementById('yearOfStudy').onchange = calculateFee;

// We also need to update toggleDynamicOptions to recalculate the fee when switching categories
const originalToggle = toggleDynamicOptions;
toggleDynamicOptions = function() {
    originalToggle(); // run the hide/show logic
    calculateFee();   // recalculate in case workshop was hidden
};

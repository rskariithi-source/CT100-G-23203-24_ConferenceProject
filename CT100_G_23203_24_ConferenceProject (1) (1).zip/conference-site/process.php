<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Confirmation</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Registration Status</h1>
    </header>

    <main class="form-container">
        <?php
        // 1. Receive the submitted form values using $_POST
        if ($_SERVER["REQUEST_METHOD"] == "POST") {

            // 2. Perform server-side validation on the values received
            $errors = [];

            if (empty($_POST['fullName']) || empty($_POST['regNumber']) || empty($_POST['email']) || empty($_POST['confDays'])) {
                $errors[] = "Essential registration details are missing.";
            }
            if (!empty($_POST['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
                $errors[] = "Please enter a valid email address.";
            }
            if (!isset($_POST['phone']) || !preg_match('/^\d{10}$/', $_POST['phone'])) {
                $errors[] = "Phone number must contain exactly 10 digits.";
            }
            $confDays = (int)($_POST['confDays'] ?? 0);
            if (!empty($_POST['confDays']) && ($confDays < 1 || $confDays > 3)) {
                $errors[] = "Number of conference days must be between 1 and 3.";
            }
            $allowedCategories = ["Conference Only", "Workshop Participant"];
            if (!isset($_POST['category']) || !in_array($_POST['category'], $allowedCategories, true)) {
                $errors[] = "Please select a valid participation category.";
            }

            if (!empty($errors)) {
                echo "<div class='error'>";
                foreach ($errors as $message) {
                    echo "Error: " . htmlspecialchars($message) . "<br>";
                }
                echo "Please go back and try again.</div>";
                echo "<a href='register.html' class='btn'>Back to Form</a>";
                echo "</main></body></html>";
                exit();
            }

            // Sanitize and store inputs
            $fullName = htmlspecialchars($_POST['fullName']);
            $regNumber = htmlspecialchars($_POST['regNumber']);
            $email = htmlspecialchars($_POST['email']);
            $yearOfStudy = htmlspecialchars($_POST['yearOfStudy'] ?? '');
            $category = $_POST['category'];

            // Check optional fields
            $workshopSelect = !empty($_POST['workshopSelect']) ? htmlspecialchars($_POST['workshopSelect']) : 'N/A';
            $mealOption = isset($_POST['mealOption']) ? "Yes" : "No";

            // 3. Independently calculate or verify the total amount payable
            $totalFee = 0;
            $regFee = 1000;
            $attendancePerDay = 500;
            $workshopCharge = 750;
            $lunchPerDay = 300;

            // Add Base Registration Fee
            $totalFee += $regFee;

            // Add Attendance Fee (Days x 500)
            $totalFee += ($confDays * $attendancePerDay);

            // Add Workshop Fee if applicable
            if ($category === "Workshop Participant") {
                $totalFee += $workshopCharge;
            } else {
                $workshopSelect = 'N/A'; // Ensure it says N/A if they just chose Conference Only
            }

            // Add Meal Fee if applicable
            if ($mealOption === "Yes") {
                $totalFee += ($confDays * $lunchPerDay);
            }

            // INDIVIDUALIZATION REQUIREMENT: Give final-year students a 5% discount
            if ($yearOfStudy === "Final Year") {
                $totalFee = $totalFee * 0.95;
            }

            // 4. Display a personalized registration confirmation
            echo "<div class='summary-box'>";
            echo "<h2>REGISTRATION SUCCESSFUL</h2>";
            echo "<p><strong>Participant:</strong> " . $fullName . "</p>";
            echo "<p><strong>Admission Number:</strong> " . $regNumber . "</p>";
            echo "<p><strong>Email:</strong> " . $email . "</p>";
            echo "<p><strong>Conference Days:</strong> " . $confDays . "</p>";
            echo "<p><strong>Workshop:</strong> " . $workshopSelect . "</p>";
            echo "<p><strong>Meals:</strong> " . $mealOption . "</p>";

            // Format number to 2 decimal places for currency
            echo "<h3>TOTAL AMOUNT PAYABLE: KSh " . number_format($totalFee, 2) . "</h3>";
            echo "<p>Thank you for registering for the Student Technology and Innovation Conference.</p>";
            echo "</div>";

        } else {
            // Redirect or show error if accessed directly without POST
            echo "<div class='error'>Invalid request method.</div>";
        }
        ?>
        <a href="index.html" class="btn">Return to Home</a>
    </main>
</body>
</html>
